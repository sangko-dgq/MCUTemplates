
#ifndef	__STC32G_SOFT_UART_H
#define	__STC32G_SOFT_UART_H

#include	"FreeRTOS.h"

void	TxSend(uint8_t dat);
void 	PrintString(uint8_t code *puts);

#endif
